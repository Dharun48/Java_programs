/******************************************************************************
Q10.Java Program to check whether the sum of two numbers is even or odd

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner s=new Scanner(System.in);
	    int a=s.nextInt();
	    int b=s.nextInt();
	    int c=a+b;
	    if(c%2==0)
	    {
		System.out.println("Even");
	    }
	    else
	    {
	        System.out.println("Odd");
	    }
	}
}
